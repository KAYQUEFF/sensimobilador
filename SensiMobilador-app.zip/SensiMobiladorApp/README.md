# Sensi Mobilador (app com painel flutuante)
1. Compile (Android Studio ou GitHub Actions) e instale o APK.
2. Abra o app, escolha jogo, mapeador, mouse, DPI, estilo e mousepad.
3. Toque em COMEÇAR: permita a sobreposição, o jogo abre e o botao "SM" aparece.
4. Toque no "SM" para abrir o painel; arraste para mover. Use − e + para ajustar cada valor.

Hz: o app lista só os Hz que a tela suporta e aplica via root (se houver) ou pela permissao
"Modificar configuracoes do sistema". RESTAURAR TUDO volta o Hz original e apaga as configuracoes.
O Hz do mouse e definido no proprio mouse; o app apenas registra o valor.
