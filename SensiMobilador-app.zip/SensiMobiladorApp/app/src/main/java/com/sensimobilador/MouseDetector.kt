package com.sensimobilador

import java.io.File
import java.util.concurrent.TimeUnit

object MouseDetector {
    private val ignore = listOf("uinput", "virtual", "gpio", "fpc", "touch", "fingerprint")

    fun parse(text: String): String? {
        var name = ""
        for (raw in text.lines()) {
            val l = raw.trim()
            if (l.startsWith("N: Name=")) {
                name = l.removePrefix("N: Name=").trim().trim('"')
            } else if (l.startsWith("H: Handlers=") && l.contains("mouse")) {
                val low = name.lowercase()
                if (name.isNotEmpty() && ignore.none { low.contains(it) }) return name
            }
        }
        return null
    }

    private fun direct(): String? = try {
        val t = File("/proc/bus/input/devices").readText()
        if (t.isBlank()) null else parse(t)
    } catch (t: Throwable) { null }

    private fun viaSu(): String? = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "cat /proc/bus/input/devices"))
        val t = p.inputStream.bufferedReader().readText()
        p.waitFor(3, TimeUnit.SECONDS)
        parse(t)
    } catch (t: Throwable) { null }

    /** Bloqueante: chame fora da thread principal. */
    fun detect(): String? = direct() ?: viaSu()
}
