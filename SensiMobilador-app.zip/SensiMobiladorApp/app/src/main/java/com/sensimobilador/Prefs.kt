package com.sensimobilador

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("sensi", Context.MODE_PRIVATE)

    var game: Int
        get() = sp.getInt("game", 0).coerceIn(0, Calc.games.size - 1)
        set(v) { sp.edit().putInt("game", v).apply() }
    var mapper: Int
        get() = sp.getInt("mapper", 0).coerceIn(0, Calc.mappers.size - 1)
        set(v) { sp.edit().putInt("mapper", v).apply() }
    var dpi: Int
        get() = sp.getInt("dpi", 1).coerceIn(0, Calc.dpis.size - 1)
        set(v) { sp.edit().putInt("dpi", v).apply() }
    var style: Int
        get() = sp.getInt("style", 1).coerceIn(0, Calc.styles.size - 1)
        set(v) { sp.edit().putInt("style", v).apply() }
    var pad: Int
        get() = sp.getInt("pad", 1).coerceIn(0, Calc.pads.size - 1)
        set(v) { sp.edit().putInt("pad", v).apply() }
    var mouse: String
        get() = sp.getString("mouse", "") ?: ""
        set(v) { sp.edit().putString("mouse", v).apply() }
    var openGame: Boolean
        get() = sp.getBoolean("openGame", true)
        set(v) { sp.edit().putBoolean("openGame", v).apply() }

    var mouseHz: Int
        get() = sp.getInt("mouseHz", 3).coerceIn(0, Calc.mouseHzs.size - 1)
        set(v) { sp.edit().putInt("mouseHz", v).apply() }
    var phoneHz: Int
        get() = sp.getInt("phoneHz", 0)
        set(v) { sp.edit().putInt("phoneHz", v).apply() }
    var origSaved: Boolean
        get() = sp.getBoolean("origSaved", false)
        set(v) { sp.edit().putBoolean("origSaved", v).apply() }
    var origMin: String
        get() = sp.getString("origMin", "") ?: ""
        set(v) { sp.edit().putString("origMin", v).apply() }
    var origPeak: String
        get() = sp.getString("origPeak", "") ?: ""
        set(v) { sp.edit().putString("origPeak", v).apply() }

    fun clearAll() { sp.edit().clear().apply() }

    fun off(g: Int, i: Int) = sp.getInt("off_${g}_$i", 0)
    fun setOff(g: Int, i: Int, v: Int) { sp.edit().putInt("off_${g}_$i", v).apply() }
    var mapOff: Int
        get() = sp.getInt("off_map", 0)
        set(v) { sp.edit().putInt("off_map", v).apply() }
}
