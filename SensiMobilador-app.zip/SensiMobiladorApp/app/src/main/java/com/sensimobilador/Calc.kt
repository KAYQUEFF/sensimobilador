package com.sensimobilador

import android.content.Context
import android.content.Intent

class Field(val name: String, val base: IntArray)

class GameDef(val name: String, val pkg: String, val fields: List<Field>) {
    fun isInstalled(ctx: Context) = ctx.packageManager.getLaunchIntentForPackage(pkg) != null

    fun launch(ctx: Context): Boolean {
        val i = ctx.packageManager.getLaunchIntentForPackage(pkg) ?: return false
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
        return true
    }
}

object Calc {
    private val ff = listOf(
        Field("Geral", intArrayOf(95, 85, 72)),
        Field("Ponto vermelho", intArrayOf(92, 82, 70)),
        Field("Mira 2x", intArrayOf(88, 78, 65)),
        Field("Mira 4x", intArrayOf(85, 72, 60)),
        Field("AWM", intArrayOf(75, 65, 52)),
        Field("Olhar livre", intArrayOf(80, 70, 60))
    )
    private val cod = listOf(
        Field("Câmera (sem mira)", intArrayOf(90, 80, 68)),
        Field("Ponto vermelho", intArrayOf(85, 75, 63)),
        Field("Mira 2x a 3x", intArrayOf(78, 68, 56)),
        Field("Mira 4x ou mais", intArrayOf(70, 60, 50)),
        Field("Sniper", intArrayOf(60, 50, 42))
    )
    private val pubg = listOf(
        Field("Câmera (sem mira)", intArrayOf(90, 80, 68)),
        Field("Ponto vermelho / holo", intArrayOf(85, 75, 63)),
        Field("Mira 2x", intArrayOf(78, 68, 56)),
        Field("Mira 3x a 4x", intArrayOf(70, 60, 50)),
        Field("Mira 6x a 8x", intArrayOf(58, 48, 40))
    )

    val games = listOf(
        GameDef("Free Fire", "com.dts.freefireth", ff),
        GameDef("Free Fire MAX", "com.dts.freefiremax", ff),
        GameDef("Call of Duty Mobile", "com.activision.callofduty.shooter", cod),
        GameDef("PUBG Mobile", "com.tencent.ig", pubg)
    )
    val mappers = listOf("GG Mouse Pro", "Panda Mouse Pro", "Octopus", "Outro mapeador")
    val dpis = intArrayOf(400, 800, 1000, 1200, 1600, 3200)
    val styles = listOf("Rush / agressivo", "Equilibrado", "Precisão / mid-range")
    val pads = listOf("Pequeno", "Médio", "Grande")
    val padF = doubleArrayOf(1.1, 1.0, 0.9)
    val mouseHzs = intArrayOf(125, 250, 500, 1000)
    private val mapBase = intArrayOf(55, 45, 35)

    private fun clamp(v: Int, a: Int, b: Int) = maxOf(a, minOf(b, v))

    fun fieldValue(f: Field, style: Int, dpi: Int, pad: Double, off: Int): Int {
        val v = clamp(Math.round(f.base[style] * Math.pow(800.0 / dpi, 0.25) * pad).toInt(), 15, 100)
        return clamp(v + off, 1, 100)
    }

    fun mapperValue(style: Int, dpi: Int, pad: Double, off: Int): Int {
        val v = clamp(Math.round(mapBase[style] * Math.pow(800.0 / dpi, 0.5) * pad).toInt(), 5, 100)
        return clamp(v + off, 1, 100)
    }

    private val rules = listOf(
        Regex("\\bm(90|170|185|220|280)\\b") to 1000,
        Regex("\\bg(102|203|305|402|502)\\b|g pro") to 800,
        Regex("razer|deathadder|viper|basilisk") to 800,
        Regex("redragon|cobra|griffin|centrophorus|\\bm(601|711|908|901)\\b") to 800,
        Regex("hyperx|pulsefire") to 800,
        Regex("attack ?shark|fantech|havit|dazz|gamer") to 800,
        Regex("multilaser|comum|office|escrit|gen[eé]rico|sem marca") to 1000
    )

    /** DPI típico para o modelo, ou null se não reconhecer. */
    fun dpiForMouse(name: String): Int? {
        val n = name.lowercase().trim()
        if (n.isEmpty()) return null
        return rules.firstOrNull { it.first.containsMatchIn(n) }?.second
    }
}
