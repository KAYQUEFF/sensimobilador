package com.sensimobilador

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private lateinit var prefs: Prefs
    private var bubble: TextView? = null
    private var scroll: ScrollView? = null
    private var content: LinearLayout? = null
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private lateinit var panelLp: WindowManager.LayoutParams
    private var panelH = 0
    private val ui = Handler(Looper.getMainLooper())
    private val panelW get() = dp(270)

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        prefs = Prefs(this)
        startAsForeground()
        createBubble()
        createPanel()
        render()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") stopSelf() else render()
        return START_NOT_STICKY
    }

    private fun startAsForeground() {
        val chId = "sensimobilador"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(chId, "Sensi Mobilador", NotificationManager.IMPORTANCE_LOW))
        }
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, OverlayService::class.java).setAction("STOP"),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, chId)
                else Notification.Builder(this)
        val n = b.setContentTitle("Sensi Mobilador ativo")
            .setContentText("Toque aqui para encerrar o menu")
            .setSmallIcon(android.R.drawable.ic_menu_manage)
            .setContentIntent(stop)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else startForeground(1, n)
    }

    private fun baseParams(w: Int, h: Int) = WindowManager.LayoutParams(
        w, h,
        WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
        PixelFormat.TRANSLUCENT
    ).apply { gravity = Gravity.TOP or Gravity.START }

    private fun createBubble() {
        val size = dp(52)
        val b = TextView(this).apply {
            text = "SM"
            textSize = 15f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            background = GradientDrawable().apply {
                shape = GradientDrawable.OVAL
                setColor(Color.parseColor("#E53935"))
                setStroke(dp(2), Color.WHITE)
            }
        }
        bubble = b
        bubbleLp = baseParams(size, size).apply { x = dp(16); y = dp(200) }

        val slop = ViewConfiguration.get(this).scaledTouchSlop
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = bubbleLp.x; sy = bubbleLp.y
                    tx = e.rawX; ty = e.rawY; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (e.rawX - tx).toInt(); val dy = (e.rawY - ty).toInt()
                    if (Math.abs(dx) > slop || Math.abs(dy) > slop) moved = true
                    if (moved) {
                        bubbleLp.x = sx + dx; bubbleLp.y = sy + dy
                        wm.updateViewLayout(b, bubbleLp)
                        if (scroll?.visibility == View.VISIBLE) positionPanel()
                    }
                }
                MotionEvent.ACTION_UP -> if (!moved) togglePanel()
            }
            true
        }
        wm.addView(b, bubbleLp)
    }

    private fun createPanel() {
        val c = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
        }
        val sv = ScrollView(this).apply {
            background = GradientDrawable().apply {
                cornerRadius = dp(14).toFloat()
                setColor(Color.parseColor("#F015151F"))
                setStroke(dp(1), Color.parseColor("#E53935"))
            }
            visibility = View.GONE
            addView(c)
        }
        content = c
        scroll = sv
        panelH = (resources.displayMetrics.heightPixels * 0.7).toInt()
        panelLp = baseParams(panelW, panelH)
        wm.addView(sv, panelLp)
    }

    private fun positionPanel() {
        val sv = scroll ?: return
        val dm = resources.displayMetrics
        var x = bubbleLp.x + dp(60)
        if (x + panelW > dm.widthPixels) x = (bubbleLp.x - panelW - dp(10)).coerceAtLeast(0)
        var y = bubbleLp.y
        if (y + panelH > dm.heightPixels) y = (dm.heightPixels - panelH).coerceAtLeast(0)
        panelLp.x = x; panelLp.y = y
        wm.updateViewLayout(sv, panelLp)
    }

    private fun togglePanel() {
        val sv = scroll ?: return
        if (sv.visibility == View.VISIBLE) sv.visibility = View.GONE
        else { render(); positionPanel(); sv.visibility = View.VISIBLE }
    }

    private fun openWriteSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:$packageName"))
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            )
        } catch (_: Exception) {}
    }

    // ---------- UI helpers ----------
    private fun tv(t: String, size: Float = 13f, color: Int = Color.WHITE) =
        TextView(this).apply { text = t; textSize = size; setTextColor(color) }

    private fun btn(t: String, onClick: () -> Unit) = TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(Color.WHITE)
        gravity = Gravity.CENTER
        setPadding(dp(10), dp(8), dp(10), dp(8))
        background = GradientDrawable().apply {
            cornerRadius = dp(8).toFloat()
            setColor(Color.parseColor("#2E2E42"))
        }
        setOnClickListener { onClick() }
    }

    private fun lp() = LinearLayout.LayoutParams(
        LinearLayout.LayoutParams.MATCH_PARENT,
        LinearLayout.LayoutParams.WRAP_CONTENT
    ).apply { topMargin = dp(6) }

    private fun row(name: String, v: Int, minus: () -> Unit, plus: () -> Unit): LinearLayout {
        val r = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        r.addView(tv(name).apply {
            layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
        })
        r.addView(btn("−", minus).apply { minWidth = dp(40) })
        r.addView(tv(v.toString(), 18f, Color.parseColor("#FF5252")).apply {
            gravity = Gravity.CENTER
            minWidth = dp(44)
        })
        r.addView(btn("+", plus).apply { minWidth = dp(40) })
        return r
    }

    private fun summary(): String {
        val g = Calc.games[prefs.game]
        val dpi = Calc.dpis[prefs.dpi]
        val pf = Calc.padF[prefs.pad]
        val sb = StringBuilder()
        sb.append("${g.name} | ${Calc.mappers[prefs.mapper]} | ")
        sb.append("${prefs.mouse.ifEmpty { "Mouse" }} | DPI $dpi\n")
        g.fields.forEachIndexed { i, f ->
            sb.append("${f.name}: ${Calc.fieldValue(f, prefs.style, dpi, pf, prefs.off(prefs.game, i))}\n")
        }
        sb.append("Hz do mouse: ${Calc.mouseHzs[prefs.mouseHz]}\n")
        sb.append("Hz do celular: ${if (prefs.phoneHz == 0) "sem alteração" else "${prefs.phoneHz}"}\n")
        sb.append("Mapeador X/Y: ${Calc.mappers[prefs.mapper]} ${Calc.mapperValue(prefs.style, dpi, pf, prefs.mapOff)}")
        return sb.toString()
    }

    private fun render() {
        val c = content ?: return
        c.removeAllViews()
        val gi = prefs.game
        val g = Calc.games[gi]
        val dpi = Calc.dpis[prefs.dpi]
        val pf = Calc.padF[prefs.pad]

        c.addView(tv("Sensi Mobilador", 17f, Color.parseColor("#FF5252")))
        c.addView(tv("Toque nas opções para mudar", 11f, Color.GRAY))

        c.addView(btn("Jogo: ${g.name}") {
            prefs.game = (prefs.game + 1) % Calc.games.size; render()
        }, lp())
        c.addView(btn("Mapeador: ${Calc.mappers[prefs.mapper]}") {
            prefs.mapper = (prefs.mapper + 1) % Calc.mappers.size; render()
        }, lp())
        c.addView(btn("DPI do mouse: $dpi") {
            prefs.dpi = (prefs.dpi + 1) % Calc.dpis.size; render()
        }, lp())
        c.addView(btn("Estilo: ${Calc.styles[prefs.style]}") {
            prefs.style = (prefs.style + 1) % Calc.styles.size; render()
        }, lp())
        c.addView(btn("Mousepad: ${Calc.pads[prefs.pad]}") {
            prefs.pad = (prefs.pad + 1) % Calc.pads.size; render()
        }, lp())

        c.addView(btn("Hz do mouse: ${Calc.mouseHzs[prefs.mouseHz]}") {
            prefs.mouseHz = (prefs.mouseHz + 1) % Calc.mouseHzs.size; render()
        }, lp())
        val hzItems = listOf(0) + HzTools.supported(this)
        val phoneTxt = if (prefs.phoneHz == 0) "não alterar" else "${prefs.phoneHz} Hz"
        c.addView(btn("Hz do celular: $phoneTxt (atual ${HzTools.current(this)})") {
            val next = hzItems[(hzItems.indexOf(prefs.phoneHz) + 1) % hzItems.size]
            prefs.phoneHz = next
            Thread {
                val r = if (next == 0) HzTools.restore(this, prefs) else HzTools.apply(this, prefs, next)
                ui.post {
                    Toast.makeText(this, r.msg, Toast.LENGTH_LONG).show()
                    if (r.needPermission) openWriteSettings()
                    render()
                }
            }.start()
        }, lp())

        if (prefs.mouse.isNotEmpty()) c.addView(tv("Mouse: ${prefs.mouse}", 12f, Color.LTGRAY), lp())

        c.addView(tv("No jogo", 15f, Color.parseColor("#FF5252")), lp())
        g.fields.forEachIndexed { i, f ->
            val off = prefs.off(gi, i)
            val v = Calc.fieldValue(f, prefs.style, dpi, pf, off)
            c.addView(row(f.name, v,
                { prefs.setOff(gi, i, off - 1); render() },
                { prefs.setOff(gi, i, off + 1); render() }), lp())
        }

        c.addView(tv("No mapeador (X e Y)", 15f, Color.parseColor("#FF5252")), lp())
        val mo = prefs.mapOff
        c.addView(row("Sensibilidade", Calc.mapperValue(prefs.style, dpi, pf, mo),
            { prefs.mapOff = mo - 1; render() },
            { prefs.mapOff = mo + 1; render() }), lp())

        c.addView(tv("Ajuste de 3 em 3 e teste no treino.", 11f, Color.GRAY), lp())

        c.addView(btn("Copiar valores") {
            val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("sensi", summary()))
            Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show()
        }, lp())
        c.addView(btn("Abrir ${g.name}") { g.launch(this) }, lp())
        c.addView(btn("Restaurar tudo") {
            Thread {
                val r = HzTools.restore(this, prefs)
                if (r.ok) prefs.clearAll()
                ui.post {
                    Toast.makeText(this, r.msg, Toast.LENGTH_LONG).show()
                    if (r.needPermission) openWriteSettings()
                    render()
                }
            }.start()
        }, lp())
        c.addView(btn("Fechar painel") { scroll?.visibility = View.GONE }, lp())
        c.addView(btn("Encerrar menu") { stopSelf() }, lp())
    }

    override fun onDestroy() {
        try { bubble?.let { wm.removeView(it) } } catch (_: Exception) {}
        try { scroll?.let { wm.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
