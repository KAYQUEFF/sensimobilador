package com.sensimobilador

import android.content.Context
import android.hardware.display.DisplayManager
import android.provider.Settings
import android.view.Display
import java.util.concurrent.TimeUnit

class HzResult(val ok: Boolean, val needPermission: Boolean, val msg: String)

object HzTools {
    private const val MIN = "min_refresh_rate"
    private const val PEAK = "peak_refresh_rate"

    private fun display(ctx: Context): Display? = try {
        (ctx.getSystemService(Context.DISPLAY_SERVICE) as DisplayManager)
            .getDisplay(Display.DEFAULT_DISPLAY)
    } catch (t: Throwable) { null }

    /** Taxas de atualização que a tela do aparelho realmente suporta. */
    fun supported(ctx: Context): List<Int> = try {
        display(ctx)?.supportedModes?.map { Math.round(it.refreshRate) }?.distinct()?.sorted()
            ?: emptyList()
    } catch (t: Throwable) { emptyList() }

    fun current(ctx: Context): Int = try {
        Math.round(display(ctx)?.refreshRate ?: 0f)
    } catch (t: Throwable) { 0 }

    /** Bloqueante: chame fora da thread principal. */
    private fun su(cmd: String): Boolean = try {
        val p = Runtime.getRuntime().exec(arrayOf("su", "-c", cmd))
        if (p.waitFor(5, TimeUnit.SECONDS)) {
            p.exitValue() == 0
        } else {
            p.destroy(); false
        }
    } catch (t: Throwable) { false }

    private fun saveOriginals(ctx: Context, prefs: Prefs) {
        if (prefs.origSaved) return
        val cr = ctx.contentResolver
        prefs.origMin = Settings.System.getString(cr, MIN) ?: ""
        prefs.origPeak = Settings.System.getString(cr, PEAK) ?: ""
        prefs.origSaved = true
    }

    /** Bloqueante: chame fora da thread principal. */
    fun apply(ctx: Context, prefs: Prefs, hz: Int): HzResult {
        if (hz <= 0) return HzResult(true, false, "Hz do celular: sem alteração")
        val sup = supported(ctx)
        if (sup.isNotEmpty() && hz !in sup) {
            return HzResult(false, false, "Essa tela não suporta $hz Hz")
        }
        try { saveOriginals(ctx, prefs) } catch (t: Throwable) {}
        val v = "$hz.0"
        if (su("settings put system $PEAK $v && settings put system $MIN $v")) {
            return HzResult(true, false,
                "Aplicado: $hz Hz (via root). Se a tela não mudar, o fabricante bloqueia essa opção.")
        }
        if (Settings.System.canWrite(ctx)) {
            return try {
                val cr = ctx.contentResolver
                Settings.System.putFloat(cr, PEAK, hz.toFloat())
                Settings.System.putFloat(cr, MIN, hz.toFloat())
                HzResult(true, false,
                    "Aplicado: $hz Hz. Se a tela não mudar, o fabricante bloqueia essa opção.")
            } catch (t: Throwable) {
                HzResult(false, false, "O sistema recusou a alteração do Hz")
            }
        }
        return HzResult(false, true,
            "Permita \"Modificar configurações do sistema\" para este app (ou use root) e tente de novo.")
    }

    /** Volta o Hz ao valor que o aparelho tinha antes do app mexer. */
    fun restore(ctx: Context, prefs: Prefs): HzResult {
        if (!prefs.origSaved) return HzResult(true, false, "Nada para restaurar no Hz do celular")
        val oMin = prefs.origMin
        val oPeak = prefs.origPeak
        fun cmd(key: String, o: String) =
            if (o.isEmpty()) "settings delete system $key" else "settings put system $key $o"
        if (su(cmd(PEAK, oPeak) + "; " + cmd(MIN, oMin))) {
            prefs.origSaved = false
            return HzResult(true, false, "Hz do celular restaurado")
        }
        if (Settings.System.canWrite(ctx)) {
            return try {
                val cr = ctx.contentResolver
                Settings.System.putString(cr, PEAK, if (oPeak.isEmpty()) null else oPeak)
                Settings.System.putString(cr, MIN, if (oMin.isEmpty()) null else oMin)
                prefs.origSaved = false
                HzResult(true, false, "Hz do celular restaurado")
            } catch (t: Throwable) {
                HzResult(false, false, "O sistema recusou restaurar o Hz")
            }
        }
        return HzResult(false, true,
            "Permita \"Modificar configurações do sistema\" para este app (ou use root) para restaurar.")
    }
}
