package com.sensimobilador

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: Prefs
    private lateinit var mouseEdit: EditText
    private lateinit var dpiSpinner: Spinner
    private lateinit var info: TextView
    private lateinit var hzInfo: TextView
    private lateinit var hzItems: List<Int>

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun label(t: String) = TextView(this).apply {
        text = t
        setTextColor(Color.LTGRAY)
        setPadding(0, dp(14), 0, dp(4))
    }

    private fun note(t: String) = TextView(this).apply {
        text = t
        setTextColor(Color.GRAY)
        textSize = 12f
    }

    private fun spinner(items: List<String>, sel: Int, onSel: (Int) -> Unit): Spinner {
        val s = Spinner(this)
        s.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        s.setSelection(sel)
        s.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { onSel(pos) }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        return s
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = Prefs(this)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(40), dp(20), dp(24))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Color.parseColor("#12121A"))
            addView(root)
        }

        root.addView(TextView(this).apply {
            text = "Sensi Mobilador"
            textSize = 26f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        })

        root.addView(label("Jogo"))
        root.addView(spinner(Calc.games.map { it.name }, prefs.game) { prefs.game = it })

        root.addView(label("Mapeador"))
        root.addView(spinner(Calc.mappers, prefs.mapper) { prefs.mapper = it })

        root.addView(label("Nome ou modelo do mouse"))
        mouseEdit = EditText(this).apply {
            hint = "Ex.: Logitech G203"
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
            setSingleLine()
            setText(prefs.mouse)
        }
        root.addView(mouseEdit)

        info = note("")
        root.addView(info)

        root.addView(Button(this).apply {
            text = "Detectar mouse conectado"
            setOnClickListener { detectMouse() }
        })

        root.addView(label("DPI do mouse"))
        dpiSpinner = spinner(Calc.dpis.map { it.toString() }, prefs.dpi) { prefs.dpi = it }
        root.addView(dpiSpinner)

        mouseEdit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val n = s?.toString() ?: ""
                prefs.mouse = n
                val d = Calc.dpiForMouse(n)
                if (d != null) {
                    val i = Calc.dpis.indexOf(d)
                    if (i >= 0) dpiSpinner.setSelection(i)
                }
            }
        })

        root.addView(label("Estilo de jogo"))
        root.addView(spinner(Calc.styles, prefs.style) { prefs.style = it })

        root.addView(label("Tamanho do mousepad"))
        root.addView(spinner(Calc.pads, prefs.pad) { prefs.pad = it })

        root.addView(label("Hz do mouse (taxa de polling)"))
        root.addView(spinner(Calc.mouseHzs.map { "$it Hz" }, prefs.mouseHz) { prefs.mouseHz = it })
        root.addView(note("O Hz do mouse é definido no próprio mouse (botão ou software do fabricante). Aqui você só registra o valor que usa."))

        hzItems = listOf(0) + HzTools.supported(this)
        root.addView(label("Hz do celular (taxa de atualização da tela)"))
        root.addView(spinner(
            hzItems.map { if (it == 0) "Não alterar" else "$it Hz" },
            maxOf(0, hzItems.indexOf(prefs.phoneHz))
        ) { prefs.phoneHz = hzItems[it] })
        hzInfo = note("Atual: ${HzTools.current(this)} Hz")
        root.addView(hzInfo)
        root.addView(Button(this).apply {
            text = "Aplicar Hz do celular agora"
            setOnClickListener { applyHzNow() }
        })

        root.addView(CheckBox(this).apply {
            text = "Abrir o jogo ao começar"
            setTextColor(Color.WHITE)
            isChecked = prefs.openGame
            setOnCheckedChangeListener { _, on -> prefs.openGame = on }
        })

        root.addView(Button(this).apply {
            text = "COMEÇAR"
            textSize = 18f
            setOnClickListener { start() }
        }, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(16) })

        root.addView(Button(this).apply {
            text = "RESTAURAR TUDO"
            setOnClickListener { confirmReset() }
        })

        setContentView(scroll)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
        if (prefs.mouse.isEmpty()) detectMouse()
    }

    private fun detectMouse() {
        info.text = "Procurando mouse..."
        Thread {
            val n = MouseDetector.detect()
            runOnUiThread {
                if (n != null) {
                    mouseEdit.setText(n)
                    info.text = "Mouse detectado: $n"
                } else {
                    info.text = "Nenhum mouse detectado. Digite o nome ou escolha o DPI."
                }
            }
        }.start()
    }

    private fun openWriteSettings() {
        startActivity(Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS,
            Uri.parse("package:$packageName")))
    }

    private fun showHz(r: HzResult) {
        hzInfo.text = "Atual: ${HzTools.current(this)} Hz. ${r.msg}"
        if (r.needPermission) openWriteSettings()
    }

    private fun applyHzNow() {
        val hz = prefs.phoneHz
        if (hz == 0) {
            Toast.makeText(this, "Escolha um Hz para o celular", Toast.LENGTH_SHORT).show()
            return
        }
        Thread {
            val r = HzTools.apply(this, prefs, hz)
            runOnUiThread { showHz(r) }
        }.start()
    }

    private fun confirmReset() {
        AlertDialog.Builder(this)
            .setTitle("Restaurar tudo?")
            .setMessage("O Hz do celular volta ao original e todas as configurações do app são apagadas.")
            .setPositiveButton("Restaurar") { _, _ ->
                Thread {
                    val r = HzTools.restore(this, prefs)
                    if (r.ok) prefs.clearAll()
                    runOnUiThread {
                        Toast.makeText(this, r.msg, Toast.LENGTH_LONG).show()
                        if (r.needPermission) openWriteSettings() else if (r.ok) recreate()
                    }
                }.start()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Permita a sobreposição e volte", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                Uri.parse("package:$packageName")))
            return
        }
        if (prefs.phoneHz > 0) {
            Thread {
                val r = HzTools.apply(this, prefs, prefs.phoneHz)
                runOnUiThread {
                    showHz(r)
                    if (r.needPermission) {
                        Toast.makeText(this, "Permita modificar as configurações e toque em COMEÇAR de novo",
                            Toast.LENGTH_LONG).show()
                    } else {
                        launchAll()
                    }
                }
            }.start()
        } else {
            launchAll()
        }
    }

    private fun launchAll() {
        val svc = Intent(this, OverlayService::class.java)
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(svc) else startService(svc)
        val g = Calc.games[prefs.game]
        if (prefs.openGame && !g.launch(this)) {
            Toast.makeText(this, "${g.name} não está instalado", Toast.LENGTH_LONG).show()
        }
    }
}
